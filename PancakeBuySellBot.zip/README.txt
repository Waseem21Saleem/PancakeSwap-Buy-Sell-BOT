PancakeSwap Buy & Sell BOT - V1.0 Released 31.08.2023 by Waseem Saleem
'
'
'
- This app helps you buy and sell BSC tokens from PancakeSwap faster, cheaper and easier than any website
- No data gets saved, and it is for free.. 
- No transactions are made except those appear on the application it self (Buy/Approve/Sell)
- Only works for BSC tokens that has 0% Buy/Sell tax 
'
'
'
How to use:
	1. Paste your wallet's private key ( you can get it from MetaMask/Trust wallet... ).
	2. Press Connect and the app will show you your wallet address, BNB balance and its worth in BUSD.
	Buy tokens:
		3. Paste the address of the token you want to buy ( you can get it from bscScan/coinMarketCap... ).
		4. Press Check balance and the app will show you your token balance and its worth in BUSD.
		5. Enter the amount of BNB you want to spend and press Buy.
		6. The status of the buy proccess will appear and the transaction link as well (if succeeded).
	Sell tokens:
		7. Paste the address of the token you want to sell ( you can get it from bscScan/coinMarketCap... ).
		8. Press Check balance and the app will show you your token balance and its worth in BUSD.
		9. Enter the amount of tokens you want to sell and press Sell.
		10.The status of the sell proccess will appear and the approval&transaction link as well (if succeeded).


Personal Links:
	LinkedIn: https://www.linkedin.com/in/waseem-saleem-276432248/
	GitHub: https://github.com/Waseem21Saleem

-Please leave comments bellow in GitHub if you find any error, specify the token you were trying to buy/sell and I will try my best to fix it asap.

